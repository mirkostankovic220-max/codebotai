import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export const SYSTEM_PROMPT = `You are CodeMind AI, a world-class programming assistant. 
Your goal is to help users with coding tasks in Python, Lua, JavaScript, C++, and Java.
You can:
1. Generate high-quality, efficient code.
2. Fix bugs and suggest optimizations.
3. Explain code step-by-step.
4. Answer general programming questions.

When providing code:
- Use markdown code blocks with the correct language tag.
- Keep explanations concise but thorough.
- If the user asks for optimization, explain why the new version is better.
- If the user asks for a bug fix, point out the error and how to avoid it in the future.

Always be professional, helpful, and encouraging.`;

export async function getChatResponse(messages: { role: string; content: string }[]) {
  const model = "gemini-3-flash-preview";
  
  const history = messages.slice(0, -1).map(m => ({
    role: m.role === "user" ? "user" : "model",
    parts: [{ text: m.content }]
  }));

  const chat = ai.chats.create({
    model,
    config: {
      systemInstruction: SYSTEM_PROMPT,
    },
    history: history as any,
  });

  const lastMessage = messages[messages.length - 1].content;
  const result = await chat.sendMessage({ message: lastMessage });
  return result.text;
}
